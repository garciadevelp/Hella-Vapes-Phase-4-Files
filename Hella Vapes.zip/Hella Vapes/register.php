<!DOCTYPE html>
<html>
    
    <head>
        <meta charset="utf-8">
        <title>Hella Vapes: Register Complete</title>
        <meta name="description" content="Registration Page for Hella Vapes">
        <link rel="stylesheet" href="CSS/hella.css">      
        <script src="js/hella.js"></script>
        <script src="js/jquery-ui-1.12.1.custom"></script>
    </head>
    <body>
    
    <nav id="top-nav">
        <a href="login.html">Login</a> 
        <a href="register.html">Register</a>
        <a href="cart.html">Cart</a> 
    </nav>
    
    <header><div id="page-header-image"><img src="Images/registerheader.png" alt=" Contact Header" id="page-header"></div></header>
    
    <nav id="main-nav">
        <a href="index.html">Home</a> |
          <div class="dropdown">
               <button class="dropbtn"><a href="juice.html">Shop Juice</a></button> |
                <div class="dropdown-content">
                    <a href="freebase.html">Free-Base Juice</a>
                    <a href="saltnic.html">Salt-Nic Juice</a>
                </div>
            </div> 
           <div class="dropdown">
               <button class="dropbtn"><a href="hardware.html">Shop Hardware</a></button> |
                <div class="dropdown-content">
                    <a href="sub-ohm.html">Sub-Ohm Kits</a>
                    <a href="all-in-one.html">All-In-One Kits</a>
                    <a href="mods.html">Mods</a>
                    <a href="tanks.html">Tanks</a>
                    <a href="coils.html">Coils</a>
                    <a href="parts.html">Parts</a>
                </div>
            </div> 
        <a href="service.html">Customer Service</a>
    </nav>
    
    <div id="content">
        <h1>Welcome Aboard!</h1>
        <?php
        $servername = "us114.siteground.us";
        $username = "garciad3_hellava";
        $password = "Password12345";
        $dbname = "garciad3_hellavapes";

        $fname = $_POST["rfname"];
        $lname = $_POST["rlname"];
        $email = $_POST["remail"];
        $address = $_POST["raddress"];
        $city = $_POST["rcity"];
        $state = $_POST["rstate"];
        $zipcode = $_POST["rzipcode"];
        $userlevel = 1;

        $pword = $_POST["rpword"];

        $link = new mysqli($servername, $username, $password, $dbname);

//$pword= sha1($_POST['rpword']); // Password Encryption, If you like you can also leave sha1.
// Check if e-mail address syntax is valid or not
/*$result = mysqli_query("SELECT * FROM users WHERE email_address='$email'");
$data = mysqli_num_rows($result);
if(($data) < 0){
    
echo "This email is already registered, Please try another email...";
}else {*/
$sql = "INSERT INTO users (user_id, first_name, last_name, email_address, acct_password, address, city, state, zipcode, user_level) VALUES (NULL,'$fname', '$lname', '$email', '$pword', '$address', '$city', '$state', '$zipcode', '$userlevel')"; // Insert query



if(mysqli_query($link, $sql)){
    echo "You have successfuly registered!";
} else{
    echo "ERROR: Was not able to execute $sql. " . mysqli_error($link);
}

mysqli_close($link);

?>

<div id="backtotop"><a href="#main-nav">Back to Top</a></div>


        </div>
        
        <footer><p id="dev-tag">Created by <a href="https://garciadevelop.com/" target="_blank">Garcia Develop</a></p>
                <p id="copywrite">Copyright © 2019 · All Rights Reserved · Hella Vapes</p>
        </footer>

    </body>
</html>